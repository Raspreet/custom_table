<?php
namespace Drupal\custom_table\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Url;
use Drupal\Core\Messenger;



class Deleteform extends ConfirmFormBase
{
   public function getformId()
   {
      return 'delete_form';
   }

   public $cid;
  
   public function getQuestion()
  {
     return t('Delete Record?');
  }

  public function getCancelUrl()
  {
     return new Url('custom_table.customtable_controller_listing');
  }

   public function getDescription()
  {
     return t('Are you sure?');
  }

  public function getConfirmText()
 {
    return t('Delete it');
  }

  public function getCancelText()
  {
     return t('Cancel');
  }

  
   
   public function submitForm(array &$form, FormStateInterface $form_state) {
       $query = \Drupal::database();
	   $current_path = \Drupal::request()->getPathInfo();
		$ex_array=explode("/",$current_path);
		$arrLength = count($ex_array);
		$cid=$ex_array[$arrLength-1];
	  
        $query->delete('custom_table')->condition('id',$cid)->execute();
		
		$this->messenger()->addMessage('Successfully Deleted Record');

	   $form_state->setRedirect('custom_table.customtable_controller_listing');
 
   }

}

?>