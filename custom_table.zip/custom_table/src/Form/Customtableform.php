<?php
namespace Drupal\custom_table\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Messenger;
use Drupal\Core\Link;

class CustomtableForm extends FormBase
{
   public function getFormid()
   {
      return 'customtable_form';
   }
 
 public function buildform(array $form, FormStateInterface $form_state)
 {
    $conn = Database::getConnection();
 
   $record = [];
   if(isset($_GET['id']))
   {
      $query = $conn->select('custom_table','m')->condition('id',$_GET['id'])->fields('m');
	  $record= $query->execute()->fetchAssoc();
   }
 
   $form['user_id']=['#type' => 'textfield','#title'=>t('user_id'),'#required'=>TRUE,'#default_value'=>(isset($_GET['id'])? $record['user_id']:''),];

     $form['node_id']=['#type' => 'textfield','#title'=>t('node_id'),'#required'=>TRUE,'#default_value'=>(isset($_GET['id'])? $record['node_id']:''),];

     $form['action']= ['#type'=>'action',];
	 $form['action']['submit'] = ['#type'=> 'submit', '#value' => t('Save'),];
	 
      
      $link = Url::fromUserInput('/custom_table/');

      $form['action']['cancel']=['#markup'=>link::fromTextAndUrl(t('Back to page'), $link,['attributes'=>['class'=>'button']])->toString(),];
     
     return $form;
 
 }

public function submitForm(array &$form, FormStateInterface $form_state)
{
   $field =  $form_state->cleanValues()->getValues('');
  
   $user_id= $field['user_id'];
   $node_id= $field['node_id'];
    
   if(isset($_GET['id']))
   {
      $field = ['user_id'=>$user_id, 'node_id'=>$node_id,];

     $query = \Drupal::database();
     $query ->update ('custom_table')->fields($field)->condition('id', $_GET['id'])->execute();
     $this->messenger()-> addMessage('Successfully Updated Records');
   }
   else
   {
       $field = ['user_id' =>$user_id, 'node_id' =>$node_id,];
       $query = \Drupal::database();
       $query->insert('custom_table')->fields($field)->execute();
       $this->messenger()->addMessage('Successfully Saved Records');
        
        $form_state->setRedirect('custom_table.customtable_controller_listing');
   }

}

}
?>