<?php
namespace Drupal\custom_table\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Messenger;

class CustomtableController extends ControllerBase
{
	public function Listing()
	{
		  //---Table Header----
		  $header = ['id'=>t('id'), 'user_id'=>t('user_id'),'node_id'=>t('node_id'),'opt'=>t('Operation'),'opt1'=>t('Operation'),];
		  $row =[];
		  
		  $conn = Database::getConnection();
		  
		  $query= $conn->select('custom_table','m');
          $query ->fields('m', ['id','user_id','node_id']);
          $result= $query->execute()->fetchAll();

          foreach($result as $value)
          {
			 $delete = Url::fromUserInput('/custom_table/Form/delete/'.$value->id);

             $edit = Url::fromUserInput ('/custom_table/Form/data?id='.$value->id);
			 
			 $row[]=['id'=>$value->id,'user_id'=>$value->user_id,'node_id'=>$value->node_id,'opt'=>Link::fromTextAndUrl('Edit',$edit)->toString(),'opt1'=>Link::fromTextAndUrl('Delete',$delete)->toString(),];
			
		  }	

          $add = Url::fromUserInput('/custom_table/Form/data');	

           $text = "Add User";
           $data['table'] = ['#type'=> 'table','#header'=>$header_table,'#rows'=>$row,'#empty'=>t('No Record Found'),'#caption'=> Link::fromTextAndUrl($text,$add)->toString(),];		   
		  $this->messenger()->addMessage('Records Listed');
		  return $data;
	}
	
}


?>