<?php
namespace Drupal\custom_table\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Messenger;
use Symfony\Component\HttpFoundation\JsonResponse;

class CustomtableController extends ControllerBase
{
	public function Listing()
	{
		  //---Table Header----
		  $header = ['id'=>t('id'), 'user_id'=>t('user_id'),'node_id'=>t('node_id'),'opt'=>t('Operation'),'opt1'=>t('Operation'),];
		  $row =[];
		  
		  $conn = Database::getConnection();
		  
		  $query= $conn->select('custom_table','m');
          $query ->fields('m', ['id','user_id','node_id']);
          $result= $query->execute()->fetchAll();

          foreach($result as $value)
          {
			 $delete = Url::fromUserInput('/custom_table/Form/delete/'.$value->id);

             $edit = Url::fromUserInput ('/custom_table/Form/data?id='.$value->id);
			 
			 $row[]=['id'=>$value->id,'user_id'=>$value->user_id,'node_id'=>$value->node_id,'opt'=>Link::fromTextAndUrl('Edit',$edit)->toString(),'opt1'=>Link::fromTextAndUrl('Delete',$delete)->toString(),];
			
		  }	

          $add = Url::fromUserInput('/custom_table/Form/data');	

           $text = "Add User";
           $data['table'] = ['#type'=> 'table','#header'=>$header_table,'#rows'=>$row,'#empty'=>t('No Record Found'),'#caption'=> Link::fromTextAndUrl($text,$add)->toString(),];		   
		  $this->messenger()->addMessage('Records Listed');
		  return $data;
	}
	
	public function APIresponse() 
	{
		    return new JsonResponse(
			 $this->getfavAPI(),
			);
	}
	
		
	public function getfavAPI()
	{
		 $conn = Database::getConnection();
		 
		  if(isset($_GET['UserId']))
		   {
			  $query = $conn->select('KC_Custom_Favorites','m')->condition('User_id',$_GET['UserId'])->fields('m');
			  $record= $query->execute()->fetchAssoc();
			  $table_fav=$record['Favorites'];
			  $result_array = json_decode($table_fav); 
			  
		   }
		  else {
			  
				  $table_query= $conn->select('kc_custom_favorites','m');
				  $table_query ->fields('m', ['user_id','favorites','created_on','created_by']);
				  $table_result= $table_query->execute()->fetchAll();
				  $result_array=[];
				  
				  foreach($table_result as $table_value)
				  {
					  $table_id=$table_value->user_id;
					  $table_fav=$table_value->favorites;
					  $table_createdon=$table_value->created_on;
					  $table_createdby=$table_value->created_by;
					  $result_array[] = json_decode($table_fav);
				  
				  }
		  
		  }
		  
		  return $result_array; 
	}
	
}


?>